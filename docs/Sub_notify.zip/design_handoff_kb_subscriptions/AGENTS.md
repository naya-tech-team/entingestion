# Project rules: KB Subscriptions

You are implementing a subscription management platform from a design handoff. Read `docs/handoff/README.md` first. The HTML in `docs/handoff/design/` is a **reference prototype**; rebuild it, don't copy it.

## Stack (do not substitute)
- Backend: Python 3.12, FastAPI, Pydantic v2, boto3. Sync endpoints are fine (FastAPI runs them in a threadpool).
- DB: DynamoDB single table `kb-subscriptions`. Table name comes from settings, never hard-coded.
- Frontend: React 18 + Vite + TypeScript (strict), React Router, TanStack Query, React Hook Form + Zod, lucide-react.
- Tests: pytest + moto for backend; Vitest + Testing Library for frontend.

## Backend conventions
- Routers never call boto3 directly; go through `app/repos/*`.
- Every key is built by `core/keys.py` helpers (e.g. `keys.sub(app_id, sub_id)` → `("APP#claims","SUB#sub_7f2a1")`). No string concatenation of keys elsewhere.
- Pydantic models use camelCase aliases on the wire (`model_config = ConfigDict(populate_by_name=True, alias_generator=to_camel)`), snake_case in Python.
- Pagination: return `{ items, nextCursor }`. Cursor = urlsafe-base64 JSON of `LastEvaluatedKey`.
- Errors: 400 bad input, 401 unauthenticated, 403 wrong role or app, 404 missing, 409 version conflict or in-use, 422 validation.
- All writes to config and subscription items use `version` with `ConditionExpression: version = :expected`. Bump on success.
- Never return secrets. Params marked `secret: true` in a channel's `paramSchema` are stored in Secrets Manager; the item stores `secret://kb/{appId}/{subId}/{channelId}/{key}` and the API returns `"••••"`.

## Invariants (must hold; write tests for each)
1. **Match keys are derived, never edited.** `core/match_keys.py::match_keys(sub, source)`:
   - SOURCE → `[M#SRC#{src}]`
   - ARTICLE → `[M#ART#{src}#{id} for id in articleIds]` (max 1,000)
   - FILTER → anchor = first ftId in `source.filterTypeIds` that has non-empty values in `sub.filters`; keys = `[M#FLT#{src}#{anchor}#{v} for v in filters[anchor]]`
   - status PAUSED → `[]`
2. **Subscription write = SUB item + match-item diff in one TransactWriteItems** when `len(puts)+len(deletes)+1 <= 100`. Otherwise write SUB only and let the reconciler (stream on `kb-subscriptions`) apply the diff idempotently.
3. Match items carry `appId, type, cadenceId, subVersion` and for FILTER the full `filters` map.
4. A filter subscription matches an article when **every** selected filter type shares **at least one** value with the article (AND across types, OR within a type).
5. App admins can only read and write data for apps where they are ADMIN. Super admins can do everything. App users can only manage subscriptions they own.
6. Hot path (worker) uses only `Query` on known PKs and `BatchGetItem`. No `Scan`, ever, anywhere in the codebase.

## Frontend conventions
- Tokens live in `src/styles/tokens.css` (copied from `design/styles.css`). Use `var(--…)`; never hard-code hex.
- **Zero border radius everywhere.** Strong 2px rules between sections. Labels flush left, including in buttons.
- Fonts: Archivo (UI), JetBrains Mono (ids, keys, code). Icons: lucide-react.
- Server state only through TanStack Query hooks in `src/api/`. Form state through React Hook Form + Zod schemas mirroring the Pydantic models.
- The subscription form is **config-driven**: sources, filter types, values, cadences, channels and channel params all come from `GET /config` and `GET /config/filter-types/{ft}/values?sourceId=`. Nothing about a specific source or channel is hard-coded.

## When unsure
Check `docs/handoff/data-model.md` and `docs/handoff/api.md` first. If something is still ambiguous, leave a `# TODO(handoff):` comment and keep going. Don't invent new entities or keys.
