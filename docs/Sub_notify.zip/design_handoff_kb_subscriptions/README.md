# Handoff: KB Subscriptions (FastAPI + DynamoDB + React)

## Overview
A subscription management platform that lets consumer apps (1,000+) subscribe to knowledge-base article changes (1M+ articles per source) by **source**, **specific articles**, or **filter values**, and receive notifications on **email, Kafka, Teams, or webhook** at a **realtime or scheduled (digest)** cadence.

It has three parts:
1. **Admin UI (React)**: super admins manage configuration; app admins manage their own subscriptions, templates and delivery logs.
2. **API (FastAPI)**: CRUD over one DynamoDB table (`kb-subscriptions`), role-based access, and server-side proxying for filter-value and article-search APIs.
3. **Notification worker (Python Lambda)**: consumes the stream of your existing article **staging table**, looks up matching subscriptions through the match index, and sends or buffers notifications.

## About the design files
The files in `design/` are **design references built in HTML**. They are a working prototype that shows the intended look and behavior; they are not production code to copy. Rebuild them in **React + TypeScript** using the stack below. All data in the prototype is sample data; nothing calls a real API.

- `design/Subscription Manager.html`: a self-contained prototype. Open it in a browser. Use the demo accounts on the login screen to switch between super admin and app admin. **Test event** (Backend) lets you paste a staging record, see the match and routing step by step, and write the result to the delivery log.
- `design/styles.css`: the design tokens (Modernist design system). Port the `:root` variables as-is.

## Fidelity
**High fidelity.** Colors, type, spacing, rules, states and copy are final. Recreate them closely. See `docs/frontend.md` for exact values.

## Target stack
| Layer | Choice |
|---|---|
| API | Python 3.12, FastAPI, Pydantic v2, boto3 (DynamoDB resource + client), uvicorn |
| Auth | OIDC/SSO JWT (bearer). Dev mode: `X-Dev-User: email` header |
| DB | DynamoDB single table `kb-subscriptions` (+ your existing staging table, read-only via Streams) |
| Secrets | AWS Secrets Manager; items store `secret://…` refs only |
| Worker | Python Lambda on the staging table's DynamoDB Stream → SQS send queue → sender Lambda |
| Schedules | EventBridge Scheduler, one schedule per CRON cadence → digest flush Lambda |
| UI | React 18, Vite, TypeScript, React Router, TanStack Query, React Hook Form + Zod, lucide-react |
| Local dev | DynamoDB Local (docker compose), seed script, moto for unit tests |
| Tests | pytest (+ moto), Vitest + Testing Library, Playwright smoke |

## Repository layout (target)
```
kb-subscriptions/
  AGENTS.md                 ← Cursor reads this (copy from this bundle)
  docker-compose.yml        ← dynamodb-local
  backend/
    pyproject.toml
    app/
      main.py               ← FastAPI app, routers, CORS, error handlers
      settings.py           ← pydantic-settings (TABLE_NAME, AWS_REGION, DDB_ENDPOINT, AUTH_*)
      auth.py               ← JWT verify, current_user dependency, role guards
      db.py                 ← table handle, pagination cursor helpers
      models/               ← Pydantic models (one file per entity)
      repos/                ← DynamoDB access per entity (no boto3 in routers)
      routers/              ← me, config, sources, templates, apps, subscriptions, deliveries, test_events
      services/
        value_resolver.py   ← filter values: source override → static | api | default
        article_search.py   ← proxy to source search API
        secrets.py          ← resolve secret:// refs (cached)
    core/                   ← shared with worker (pure Python, no FastAPI)
      keys.py               ← PK/SK builders
      match_keys.py         ← match_keys(sub, source) + diff
      matching.py           ← article → candidate keys → AND check
    scripts/
      create_table.py
      seed.py               ← loads docs/seed-data.json
    tests/
  worker/
    stream_handler.py       ← staging-table stream → match → route
    sender.py               ← SQS → channel adapters
    digest_flush.py         ← EventBridge → flush DIG# partitions
    channels/               ← email.py, kafka.py, teams.py, webhook.py
  frontend/
    src/
      styles/tokens.css     ← from design/styles.css
      api/                  ← typed client + TanStack Query hooks
      auth/                 ← session, role context, route guards
      layout/               ← Shell (Sidebar, PageHeader)
      pages/                ← one folder per screen (see docs/frontend.md)
      components/           ← Button, Chip, Segmented, Field, Select, Drawer, Toast, Table, CodePanel
```

## How to use this with Cursor
1. Create the repo and copy `AGENTS.md` to its root. Cursor loads it as project rules.
2. Put `docs/` and `design/` in the repo (e.g. `/docs/handoff`), so you can `@`-reference them.
3. Work through `docs/build-plan.md` phase by phase. Each phase has a ready-to-paste Cursor prompt and acceptance checks. Don't skip ahead: later phases depend on `core/` being correct.
4. Keep the prototype open next to the app while you build the UI.

## Docs in this bundle
| File | Contents |
|---|---|
| `AGENTS.md` | Rules for Cursor: stack, conventions, invariants that must not be broken |
| `docs/data-model.md` | Table definition, every item type with attributes, GSIs and why each one is needed, access patterns |
| `docs/api.md` | FastAPI endpoints, auth rules, request/response models, validation, errors |
| `docs/frontend.md` | Screens, layout, components, states, interactions, design tokens |
| `docs/pipeline.md` | Staging table → stream → match → send/digest; idempotency, retries, scaling |
| `docs/build-plan.md` | Phased plan with Cursor prompts and acceptance criteria |
| `docs/seed-data.json` | The prototype's sample data, as DynamoDB items for `scripts/seed.py` |

## Open items for the implementer
- **Staging table shape.** The worker assumes each staging item has `sourceId`, `changeType`, `version`, and filter metadata. The article id and title come from the source's `idPath`/`titlePath`, the same as the Test event screen. Set each source's `filterPaths` to point at the staging item, e.g. `$.filters.jurisdiction[*]`. Confirm the real attribute names first.
- **SSO provider.** Confirm the issuer and audience, and how the email claim is named.
- **Channel credentials.** Confirm SES vs SMTP, MSK auth (IAM vs SASL), and whether Teams uses webhooks or Graph.
