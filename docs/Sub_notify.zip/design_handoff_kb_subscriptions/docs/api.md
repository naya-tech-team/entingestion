# API: FastAPI

Base path `/api/v1`. JSON uses camelCase. Every route except `/health` needs `Authorization: Bearer <jwt>`. Locally, set `AUTH_MODE=dev` and send `X-Dev-User: <email>`.

## Auth & roles
`current_user` resolves the email from the JWT, then runs access pattern 1 (Query GSI1 `USER#{email}`):
```python
class AppRole(BaseModel): app_id: str; app_name: str; role: Literal["ADMIN","USER"]
class Me(BaseModel): email: str; name: str | None; is_super: bool; apps: list[AppRole]
```
Guards: `require_super`, `require_app_admin(app_id)` (super admins pass), `require_app_member(app_id)`.
App users can create subscriptions only with `ownerType=USER, ownerId=self`, and can only edit those.

## Endpoints

### Me
| Method | Path | Who | Notes |
|---|---|---|---|
| GET | `/me` | any | `Me` |
| GET | `/me/subscriptions` | any | GSI1 `begins_with SUB#` |

### Config (read: any signed-in user · write: super admin)
| Method | Path | Notes |
|---|---|---|
| GET | `/config` | `{ subTypes, filterTypes, sources, channels, cadences }`, cached 60s, ETag |
| PATCH | `/config/sub-types/{type}` | `{ enabled }` |
| POST/PUT/DELETE | `/config/filter-types[/{ftId}]` | DELETE → 409 if any source uses it |
| GET | `/config/filter-types/{ftId}/values?sourceId=` | **Value resolver** (below) → `{ values: [{value,label}], cachedUntil }` |
| POST/PUT/DELETE | `/config/sources[/{srcId}]` | PUT body includes ordered `filterTypeIds`, `filterPaths`, `filterValueCfg`. Response includes `impact` (below) |
| GET | `/config/sources/{srcId}/impact` | GSI2 → `{ total, byType, needsRebuild: [subId] }` |
| POST | `/config/sources/{srcId}/reconcile` | Recompute match keys for affected subs (async job; returns jobId) |
| POST/PUT/DELETE | `/config/channels[/{chId}]` | DELETE → 409 if in use |
| POST/PUT/DELETE | `/config/cadences[/{cadId}]` | DELETE → 409 if in use; create/update syncs the EventBridge schedule |

**Value resolver:** use `source.filterValueCfg[ftId].mode`.
- STATIC → return `values`.
- API → call the source override's `api`.
- DEFAULT or missing → fall back to the filter type's own `mode`, `values` and `api`.

API calls run server-side, with `{sourceId}` replaced in the URL and params and `secret://` headers resolved. Extract values with `valuePath` and labels with `labelPath` (jsonpath-ng). Cache the result in memory for `ttlSec`. Time out after 5s; on timeout return 502 with `{ code: "VALUE_SOURCE_UNAVAILABLE" }`.

**Impact:** when `filterTypeIds` order changes, or a filter type or value is removed, list the subscriptions whose derived `matchKeys` would change. The UI shows the count before saving.

### Articles
| GET | `/sources/{srcId}/articles?q=&cursor=` | Proxy to `source.api.search`; returns `{ items: [{id,title,updatedAt}], nextCursor, total }`. Used by the ARTICLE subscription picker. |

### Templates
| Method | Path | Who | Notes |
|---|---|---|---|
| GET | `/templates?appId=&channelId=` | member | Global + that app's templates |
| POST | `/templates` | super (GLOBAL) · app admin (APP, own app) | |
| PUT/DELETE | `/templates/{scope}/{tplId}` | same | DELETE → 409 if referenced by a subscription |
| POST | `/templates/preview` | member | `{ templateId \| body, sample }` → rendered text |

### Apps & members
| GET | `/apps` | super | all apps (paginate) |
| POST | `/apps` | super | `{ appId, name, admins[] }` → creates META + member items |
| PUT | `/apps/{appId}` | super | name, status, maxSubscriptions |
| GET | `/apps/{appId}/members` | app admin | |
| POST/DELETE | `/apps/{appId}/members[/{email}]` | app admin | |

### Subscriptions
| Method | Path | Who | Notes |
|---|---|---|---|
| GET | `/subscriptions?sourceId=&type=&appId=&q=&cursor=` | super | GSI2 when sourceId is given; otherwise iterate app partitions (admin view, paginated) |
| GET | `/apps/{appId}/subscriptions?type=&q=&cursor=` | member | users see only their own |
| POST | `/apps/{appId}/subscriptions` | member | `SubscriptionIn` → `Subscription` |
| GET | `/apps/{appId}/subscriptions/{subId}` | member | |
| PUT | `/apps/{appId}/subscriptions/{subId}` | owner/admin | body includes `version`; 409 on mismatch |
| POST | `…/{subId}/pause` · `…/{subId}/resume` | owner/admin | pause removes match items; resume rewrites them |
| DELETE | `…/{subId}` | owner/admin | deletes SUB, match items, pending digest entries |
| POST | `/apps/{appId}/subscriptions/preview` | member | `SubscriptionIn` → `{ item, matchItems, writeCount, issues[] }`. Powers the form's right-hand panel |

```python
class ChannelSel(BaseModel):
    channel_id: str; template_id: str; params: dict[str, str]
class SubscriptionIn(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    type: Literal["FILTER","ARTICLE","SOURCE"]
    owner_type: Literal["APP","USER"]; owner_id: str
    source_id: str
    filters: dict[str, list[str]] = {}
    article_ids: list[str] = Field(default=[], max_length=1000)
    cadence_id: str
    channels: list[ChannelSel] = Field(min_length=1)
class Subscription(SubscriptionIn):
    sub_id: str; app_id: str; status: Literal["ACTIVE","PAUSED"]
    anchor_filter_type: str | None; match_keys: list[str]; version: int
    created_at: datetime; updated_at: datetime | None
```

**Validation:** return 422 with `issues: [{field, message}]` when any of these fail.
- The subscription type is enabled, and the source and cadence exist and are enabled.
- FILTER: at least one filter type has at least one value. Every ftId is in `source.filterTypeIds`, and every value is in the resolved values for that source.
- ARTICLE: 1–1,000 ids.
- Every channel exists and is enabled. Every required param in `paramSchema` is present, and email-list and url values have the right format. The template belongs to that channel and is GLOBAL or this app's.
- USER owner: `ownerId` is a member of the app.

**Write path:** see invariant 2 in `AGENTS.md`. Secrets are stored before the transaction runs; if the transaction fails, they're deleted again.

### Deliveries
| GET | `/apps/{appId}/deliveries?date=&status=&channelId=&cursor=` | member | `DLV#{app}#{date}`, newest first; stats `{sent, failed, retrying, total}` |
| GET | `/apps/{appId}/subscriptions/{subId}/deliveries?cursor=` | member | GSI3 |
| POST | `/apps/{appId}/deliveries/{deliveryId}/retry` | app admin | re-enqueue to the send queue |

### Test events
| Method | Path | Who | Notes |
|---|---|---|---|
| POST | `/test-events?send=false` | app admin, super | Body: one staging-item JSON object. Runs the same `core.matching` code as the worker. App admins only see their own app's subscriptions. `send=true` also routes the result: realtime goes to the send queue and creates a Delivery; a CRON cadence buffers to `DIG#…`. |

Response:
```json
{
  "article": { "sourceId": "ic", "articleId": "IC-220", "title": "…", "changeType": "UPDATED", "values": { "jur": ["US-CA","US-WA"], "dom": ["Tax"], "prod": ["ENT"] } },
  "queries": [{ "pk": "M#FLT#ic#jur#US-CA", "items": 1 }],
  "subscriptions": [{ "subId": "sub_7f2a1", "appId": "claims", "result": "MATCH", "matchedKey": "M#FLT#ic#jur#US-CA", "reason": "Passed Domain check" }],
  "notifications": [{ "subId": "sub_7f2a1", "channelId": "email", "mode": "DIGEST", "digestKey": "DIG#daily#2026-10-14#…", "templateId": "t-digest", "subject": "…", "body": "…", "deliveryId": null }]
}
```
`result` is one of `MATCH`, `NO_MATCH` (a non-anchor filter type failed), `SKIPPED` (paused) or `NO_HIT` (no match item). It returns 422 if `sourceId` is unknown, the id path from `source.api.idPath` returns nothing, or `changeType` isn't CREATED/UPDATED/DELETED. Test deliveries carry `test: true`.

## Errors
```json
{ "code": "VERSION_CONFLICT", "message": "Subscription changed since you opened it.", "issues": [] }
```
Codes: `VALIDATION`, `FORBIDDEN`, `NOT_FOUND`, `VERSION_CONFLICT`, `IN_USE`, `QUOTA_EXCEEDED`, `VALUE_SOURCE_UNAVAILABLE`.
