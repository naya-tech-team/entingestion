# Build plan (Cursor)

Run the phases in order. Paste each prompt into Cursor (Agent mode) with the referenced docs attached via `@`. Don't start the next phase until the acceptance checks pass.

---

## Phase 0: Scaffold
**Prompt**
> Read @AGENTS.md and @README.md. Scaffold the monorepo layout from README "Repository layout". Backend: FastAPI app with `/health`, pydantic-settings (`TABLE_NAME`, `AWS_REGION`, `DDB_ENDPOINT`, `AUTH_MODE`), ruff + mypy + pytest configured. Frontend: Vite React TS strict with React Router, TanStack Query, RHF, Zod, lucide-react; copy @design/styles.css to `src/styles/tokens.css` and import it globally. Add docker-compose with amazon/dynamodb-local on 8000. Add a Makefile: `make up`, `make api`, `make web`, `make test`.

**Accept:** `make up && make api` → `/health` 200; `make web` renders a blank page using the tokens' background colour.

## Phase 1: Table, keys, seed
**Prompt**
> Using @docs/data-model.md, write `backend/scripts/create_table.py` (exact table definition incl. GSIs, stream, TTL) and `core/keys.py` with a builder for every PK/SK in the doc. Write `scripts/seed.py` that loads @docs/seed-data.json with batch_writer. Add pytest tests for every key builder.

**Accept:** table exists locally with 3 GSIs; seed loads; key tests pass.

## Phase 2: Core matching (most important)
**Prompt**
> Implement `core/match_keys.py` (`match_keys(sub, source) -> list[str]`, `anchor_filter_type(sub, source)`, `diff(old, new) -> (puts, deletes)`) and `core/matching.py` (`candidate_keys(source, article_values)`, `filter_and(match_items, article_values)`), following AGENTS.md invariants 1, 3, 4. Pure Python, no boto3. Write exhaustive pytest cases: each type, paused, anchor follows source priority, anchor changes when priority changes, AND across types, OR within a type, unselected types unconstrained.

**Accept:** 100% branch coverage on both modules.

## Phase 3: Auth & config API
**Prompt**
> Implement `app/auth.py` (JWT via python-jose + JWKS; dev mode uses X-Dev-User) and `/me` per @docs/api.md using GSI1. Implement repos and routers for sub-types, filter-types, sources, channels, cadences with version-conditioned writes and 409s. Implement `services/value_resolver.py` (override → static/api/default, jsonpath-ng, ttl cache, 5s timeout, secret:// resolution) and `GET /config/filter-types/{ftId}/values`. Implement `/config/sources/{srcId}/impact` using GSI2 and core.match_keys. Tests with moto.

**Accept:** seeded super admin (`dana.ruiz@kb.internal`) sees `isSuper: true`; app admin sees only their app; the values endpoint returns IC's static `dom` override.

## Phase 4: Subscriptions, templates, apps, deliveries API
**Prompt**
> Implement the remaining routers from @docs/api.md. Subscription create/update/delete/pause/resume must follow AGENTS.md invariant 2 (TransactWriteItems with match diff + app.subCount; fallback for >99 items). Implement full validation returning 422 issues. Implement `/subscriptions/preview` returning item, matchItems, writeCount, issues. Secrets go to Secrets Manager (moto in tests). Deliveries list by day and by subscription (GSI3). Implement `POST /test-events` per @docs/api.md "Test events". It reuses `core.matching` (no copy of the logic), runs a dry run by default, and with `send=true` routes through the same functions the worker uses.

**Accept:** creating the sample `sub_7f2a1` writes exactly 1 SUB + 2 match items; changing the source's priority to put `dom` first and calling reconcile rewrites it to `M#FLT#ic#dom#Tax`; app user can't edit an APP-owned sub (403). Posting the IC sample to `/test-events` returns `sub_7f2a1` as MATCH on `M#FLT#ic#jur#US-CA` with an email DIGEST notification. With `region`/`dom` changed so a non-anchor filter fails, it returns NO_MATCH.

## Phase 5: Frontend shell & auth
**Prompt**
> Build the Shell (Sidebar, PageHeader), routes per role, `useMe`, and the Login page per @docs/frontend.md "Shell" and "Screens 1". Match the prototype @design/Subscription Manager.html exactly: 0 radius, 2px rules, Archivo/JetBrains Mono, flush-left button labels, accent active nav. Build base components: Button (primary/secondary/ghost/icon), Chip, Segmented, Field, Select, Drawer, Toast (with Undo), DataTable, CodePanel.

**Accept:** both roles render the correct nav; visual check against the prototype.

## Phase 6: Subscriptions list + form
**Prompt**
> Build Subscriptions list and the config-driven Subscription form per @docs/frontend.md screens 2–3. All options come from useConfig and the values endpoint; article picker uses `/sources/{id}/articles`. Right panel shows Checks + "DynamoDB writes on save" from the preview endpoint (debounced 300ms). Edit sends `version`; handle 409 with a reload prompt.

**Accept:** create, edit, pause, resume, delete with undo all work end-to-end against local API; changing source resets invalid selections.

## Phase 7: Config screens, templates, apps, delivery log
**Prompt**
> Build screens 4–13 from @docs/frontend.md (including Test event). Sources editor supports reordering filter types (priority), per-type JSONPath and value source override, and shows the impact count before save. Filter types editor has a Test button calling the resolver.

**Accept:** each screen round-trips to the API; deleting an in-use cadence/channel shows the 409 toast. Test event: each sample renders all four sections. Sending one adds the rows to the delivery log.

## Phase 8: Worker
**Prompt**
> Implement `worker/stream_handler.py`, `sender.py`, `digest_flush.py`, and channel adapters per @docs/pipeline.md, reusing `backend/core`. Include idempotency, partial batch failures, Retryable/Permanent errors, Delivery item updates, EMF metrics. Add a local harness `worker/replay.py` that takes a staging item JSON and runs the handler against DynamoDB Local, printing matches and routing.

**Accept:** replaying the IC-55120 sample yields `sub_b2d55` → realtime send and `sub_7f2a1` → DIG#daily#…#07, matching the walkthrough in the prototype's Data model screen.

## Phase 9: Infra & hardening
**Prompt**
> Add IaC (CDK Python or Terraform, ask me which) for the table, Lambdas, SQS + DLQs, EventBridge Scheduler role, Secrets Manager access, API on ECS Fargate or Lambda (Mangum), alarms from @docs/pipeline.md "Observability". Add Playwright smoke tests for login → create subscription → see it in list.

**Accept:** deploys to a dev account; alarms exist; smoke test green.
