# Data model: `kb-subscriptions` (DynamoDB, single table)

## Table definition
```json
{
  "TableName": "kb-subscriptions",
  "BillingMode": "PAY_PER_REQUEST",
  "AttributeDefinitions": [
    {"AttributeName": "PK", "AttributeType": "S"}, {"AttributeName": "SK", "AttributeType": "S"},
    {"AttributeName": "GSI1PK", "AttributeType": "S"}, {"AttributeName": "GSI1SK", "AttributeType": "S"},
    {"AttributeName": "GSI2PK", "AttributeType": "S"}, {"AttributeName": "GSI2SK", "AttributeType": "S"},
    {"AttributeName": "GSI3PK", "AttributeType": "S"}, {"AttributeName": "GSI3SK", "AttributeType": "S"}
  ],
  "KeySchema": [{"AttributeName": "PK", "KeyType": "HASH"}, {"AttributeName": "SK", "KeyType": "RANGE"}],
  "GlobalSecondaryIndexes": [
    {"IndexName": "GSI1", "KeySchema": [{"AttributeName": "GSI1PK", "KeyType": "HASH"}, {"AttributeName": "GSI1SK", "KeyType": "RANGE"}],
     "Projection": {"ProjectionType": "INCLUDE", "NonKeyAttributes": ["name","role","appName","status","appId","type","sourceId","cadenceId"]}},
    {"IndexName": "GSI2", "KeySchema": [{"AttributeName": "GSI2PK", "KeyType": "HASH"}, {"AttributeName": "GSI2SK", "KeyType": "RANGE"}],
     "Projection": {"ProjectionType": "INCLUDE", "NonKeyAttributes": ["name","status","appId","filters","anchorFilterType","matchKeys","version"]}},
    {"IndexName": "GSI3", "KeySchema": [{"AttributeName": "GSI3PK", "KeyType": "HASH"}, {"AttributeName": "GSI3SK", "KeyType": "RANGE"}],
     "Projection": {"ProjectionType": "INCLUDE", "NonKeyAttributes": ["status","channelId","articleId","articleIds","attempts","error","sentAt"]}}
  ],
  "StreamSpecification": {"StreamEnabled": true, "StreamViewType": "NEW_AND_OLD_IMAGES"},
  "TimeToLiveSpecification": {"AttributeName": "expiresAt", "Enabled": true},
  "PointInTimeRecoverySpecification": {"PointInTimeRecoveryEnabled": true}
}
```

Every item also has `entity` (S) and `createdAt` (S, ISO-8601 UTC). Config and subscription items also have `updatedAt` and `updatedBy`.

## Item types
Types: S string, N number, BOOL, M map, L list. **Req** means the attribute is required.

### Super admin: `PLATFORM` / `USER#{email}`
| Attr | Type | Req | Notes |
|---|---|---|---|
| email | S | ✓ | lower-cased |
| name | S | ✓ | |
| role | S | ✓ | `SUPER_ADMIN` |
| status | S | ✓ | ACTIVE \| DISABLED |
| GSI1PK / GSI1SK | S | ✓ | `USER#{email}` / `PLATFORM` |

### Consumer app: `APP#{appId}` / `META`
| Attr | Type | Req | Notes |
|---|---|---|---|
| appId | S | ✓ | slug, immutable |
| name | S | ✓ | |
| status | S | ✓ | ACTIVE \| SUSPENDED (suspended → match items removed) |
| subCount | N | ✓ | atomic counter, updated in the subscription transaction |
| maxSubscriptions | N | | quota; condition `subCount < maxSubscriptions` |

### App member: `APP#{appId}` / `USER#{email}`
| Attr | Type | Req | Notes |
|---|---|---|---|
| appId, email | S | ✓ | |
| name | S | | |
| role | S | ✓ | ADMIN \| USER |
| appName | S | ✓ | denormalised for login |
| GSI1PK / GSI1SK | S | ✓ | `USER#{email}` / `APP#{appId}` |

### Subscription type: `CFG` / `SUBTYPE#{type}`
type (FILTER\|ARTICLE\|SOURCE), name, description, enabled BOOL, matchKeyPattern.

### Filter type: `CFG` / `FT#{ftId}`
| Attr | Type | Req | Notes |
|---|---|---|---|
| ftId | S | ✓ | short id used in keys (`jur`, `dom`) |
| name | S | ✓ | |
| mode | S | ✓ | STATIC \| API (default value source) |
| values | L&lt;S&gt; | | STATIC |
| api | M | | API: `method, url, params M, headers M (secret:// refs), valuePath, labelPath, ttlSec N` |
| version | N | ✓ | |

### Source: `CFG` / `SRC#{srcId}`
| Attr | Type | Req | Notes |
|---|---|---|---|
| srcId, name | S | ✓ | |
| api | M | ✓ | `list, detail, search` URLs, `authRef`, `idPath`, `titlePath` |
| filterTypeIds | L&lt;S&gt; | ✓ | **priority order**; index 0 = preferred anchor |
| filterPaths | M | ✓ | ftId → JSONPath into the **staging item** (worker) / article payload |
| filterValueCfg | M | | ftId → `{mode: DEFAULT\|STATIC\|API, values?, api?}`; missing = DEFAULT |
| enabled | BOOL | ✓ | |
| version | N | ✓ | |

### Channel: `CFG` / `CH#{chId}`
chId, name, enabled, `paramSchema` L&lt;M&gt; of `{key, label, type: text|url|email-list|number, required, secret}`.

### Cadence: `CFG` / `CAD#{cadId}`
cadId, name, kind (REALTIME\|CRON), cron, tz (IANA), enabled.

### Template: `TPL#GLOBAL` or `TPL#APP#{appId}` / `CH#{chId}#TPL#{tplId}`
tplId, scope (GLOBAL\|APP), appId?, channelId, name, subject, body (Handlebars), version.
The available variables are `article.*`, `change.type`, `source.name`, `subscription.*`, `digest.count`, `digest.since` and `digest.items[]`.

### Subscription: `APP#{appId}` / `SUB#{subId}`
| Attr | Type | Req | Notes |
|---|---|---|---|
| subId | S | ✓ | `sub_` + 5–8 char random |
| appId, name | S | ✓ | |
| type | S | ✓ | FILTER \| ARTICLE \| SOURCE |
| ownerType | S | ✓ | APP \| USER |
| ownerId | S | ✓ | appId or email |
| sourceId | S | ✓ | |
| filters | M | | FILTER: ftId → L&lt;S&gt; |
| anchorFilterType | S | | FILTER: derived |
| articleIds | L&lt;S&gt; | | ARTICLE: ≤ 1,000 |
| cadenceId | S | ✓ | |
| channels | L&lt;M&gt; | ✓ | `{channelId, templateId, params M}` |
| status | S | ✓ | ACTIVE \| PAUSED |
| matchKeys | L&lt;S&gt; | ✓ | derived; `[]` when paused |
| version | N | ✓ | |
| GSI1PK / GSI1SK | S | | USER-owned only: `USER#{email}` / `SUB#{subId}` |
| GSI2PK / GSI2SK | S | ✓ | `SRC#{srcId}` / `TYPE#{type}#APP#{appId}#SUB#{subId}` |

### Match items: `M#SRC#{src}` · `M#ART#{src}#{articleId}` · `M#FLT#{src}#{ft}#{value}` / `SUB#{subId}`
appId, type, cadenceId, subVersion (N), filters (M, FLT only).

### Digest buffer: `DIG#{cadId}#{windowStartISO}#{shard 00..15}` / `SUB#{subId}#ART#{articleId}`
subId, appId, srcId, articleId, title, change (CREATED\|UPDATED\|DELETED), changedAt, expiresAt (N, +14d). The shard is `int(sha1(subId)) % 16`. If the same article changes again in the window, the newer change overwrites the older one.

### Delivery: `DLV#{appId}#{yyyy-mm-dd}` / `{ts}#{deliveryId}`
deliveryId (ULID), appId, subId, srcId, articleId? / articleIds? (digest), channelId, templateId, cadenceId, status (QUEUED\|SENT\|RETRYING\|FAILED), attempts N, error?, matchKey, sentAt?, GSI3PK `SUB#{subId}`, GSI3SK `{ts}`, expiresAt (+30d).

## GSIs: why each is required
| Index | Written by | Serves | Without it |
|---|---|---|---|
| **GSI1** by user | super admin, member, user-owned sub | Login: one query on `USER#{email}` returns the PLATFORM row (super admin), every app with its role, and the user's own subscriptions. Members live under `APP#`, and login only knows the email. | Full table scan per login |
| **GSI2** by source | every subscription | Sources screen counts. **Impact analysis**: when a source's filter priority, filter types or values change, every affected subscription must be found and its match keys rebuilt. The match index can't answer this because filter subscriptions only appear under their anchor values. | Scan of all subscriptions |
| **GSI3** deliveries by sub | every delivery | Subscription delivery history across days, newest first. Base table partitions deliveries by app and day to spread the highest-volume write. | Up to 30 queries + filter per view |

**Why the match index is not a GSI:** a subscription needs one entry per anchor value or article, and a GSI indexes only one key value per item. Base-table match items can also be written in the same transaction as the subscription and read with strong consistency, and they're never throttled by GSI back-pressure.

## Access patterns
| # | Pattern | Operation | Key condition |
|---|---|---|---|
| 1 | Login: role + apps | Query GSI1 | `GSI1PK = USER#{email}` |
| 2 | Load config (cache 60s) | Query | `PK = CFG` |
| 3 | Templates for app+channel, global fallback | Query ×2 | `PK = TPL#APP#{app}`, `SK begins_with CH#{ch}`; then `PK = TPL#GLOBAL` |
| 4 | App's subscriptions | Query | `PK = APP#{app}`, `SK begins_with SUB#` |
| 5 | App's members | Query | `PK = APP#{app}`, `SK begins_with USER#` |
| 6 | User's subscriptions | Query GSI1 | `GSI1PK = USER#{email}`, `GSI1SK begins_with SUB#` |
| 7 | Subscriptions on a source | Query GSI2 | `GSI2PK = SRC#{src}` [+ `begins_with TYPE#{type}`] |
| 8 | Create / update / delete sub | TransactWrite | SUB (cond. version) + match diff + app.subCount |
| 9 | Source matches | Query | `PK = M#SRC#{src}` |
| 10 | Article matches | Query | `PK = M#ART#{src}#{id}` |
| 11 | Filter matches | Query × N | `PK = M#FLT#{src}#{ft}#{v}` |
| 12 | Hydrate subs | BatchGetItem | `APP#{app}` / `SUB#{id}` (≤100) |
| 13 | Buffer digest | PutItem | `DIG#{cad}#{window}#{shard}` |
| 14 | Flush digest | Query × 16 | `DIG#{cad}#{window}#{00..15}` |
| 15 | Deliveries | Put · Query | `DLV#{app}#{day}`; GSI3 `SUB#{id}` |

## Scale notes
- Hot keys: if a match PK goes over ~10k subscriptions (e.g. `M#SRC#xchange`), shard it as `M#SRC#xchange#{0..N}` and query the shards in parallel.
- Article contents are never stored in this table. The form searches articles through the source's search API.
- CFG fits in one partition; cache it in both the API and the worker.
