# Notification pipeline

```
S3 (article bodies)          staging table (yours)            kb-subscriptions
   ▲ upload                  srcId, articleId, version,       match index, subs,
   │                         changeType, filters{…}           digest, deliveries
   └── article updater ──────────────┤
                                     │ DynamoDB Stream (NEW_AND_OLD_IMAGES)
                                     ▼  filter: INSERT|MODIFY, metadata/version changed
                          stream_handler (Lambda, batch 100, parallelization 4)
                            1. read srcId, articleId, filter values (filterPaths)
                            2. Query M#SRC, M#ART, M#FLT per value (parallel)
                            3. dedupe + AND check
                            4. BatchGet SUB items
                            5. realtime → SQS send queue │ cron → PutItem DIG#…
                                     ▼
                          sender (Lambda, SQS batch 10) → channel adapter → Delivery item
EventBridge Scheduler (per CRON cadence) → digest_flush → Query DIG#{cad}#{window}#00..15
                                                       → group by sub → SQS send queue
```

## Staging item (assumed; confirm)
```json
{ "PK": "ART#ic#IC-55120", "srcId": "ic", "articleId": "IC-55120", "version": 12,
  "changeType": "UPDATED", "title": "California SDI wage base 2027",
  "s3Key": "ic/IC-55120/v12.json", "updatedAt": "2026-10-13T19:22:41Z",
  "filters": { "jurisdiction": ["US-CA"], "domain": "Tax", "product": ["SMB"] } }
```
Set `source.filterPaths` to point at it, e.g. `{ "jur": "$.filters.jurisdiction[*]", "dom": "$.filters.domain", "prod": "$.filters.product[*]" }`.

## stream_handler
```python
def handle(event, ctx):
    failures = []
    for rec in event["Records"]:
        try:
            new = unmarshal(rec["dynamodb"].get("NewImage", {}))
            old = unmarshal(rec["dynamodb"].get("OldImage", {}))
            src = config.source(new["srcId"])
            vals = {ft: union(jp(new, src.filter_paths[ft]), jp(old, src.filter_paths[ft]))
                    for ft in src.filter_type_ids}
            keys = [k.match_src(src.id), k.match_art(src.id, new["articleId"])]
            keys += [k.match_flt(src.id, ft, v) for ft, vs in vals.items() for v in vs]
            hits = parallel_query_all(keys)                 # Query, paginate
            matched = matching.filter_and(dedupe_by_sk(hits), vals)
            subs = batch_get([k.sub(m["appId"], m["SK"][4:]) for m in matched])
            route(subs, new)                                # SQS or DIG#
        except Exception:
            failures.append({"itemIdentifier": rec["dynamodb"]["SequenceNumber"]})
    return {"batchItemFailures": failures}
```
- **Old ∪ new values:** subscribers to a value that was removed still get notified once. Make this a flag (`NOTIFY_ON_REMOVED_VALUES`) if you don't want it.
- DELETE changes: if the staging item is deleted, use the OldImage values and set `changeType = DELETED`.
- Event-source filter, to skip content-only updates:
  ```json
  {"eventName":["INSERT","MODIFY"]}
  ```
  Add a check in code that `version` changed.

## Idempotency
- Send queue message id: `{articleId}#{version}#{subId}#{channelId}`. Sender does `PutItem` with a condition so the same send is never recorded twice:
  - Key: `PK=IDEM#{that id}`, `SK=IDEM`
  - Condition: `attribute_not_exists(PK)`
  - Expiry: TTL 7 days
- Digest buffer is naturally idempotent (same PK/SK overwrite).

## Retries & failure
- Stream: `ReportBatchItemFailures`, `MaximumRetryAttempts=5`, `BisectBatchOnFunctionError=true`, on-failure destination SQS DLQ. Stream retention is 24h, so alarm on `IteratorAge > 5 min`.
- Sender: SQS visibility timeout 60s, maxReceiveCount 5 → DLQ. Before each attempt, update the Delivery item: status RETRYING and attempts+1. After the last attempt, set FAILED with the error.
- Channel adapters raise `Retryable` (5xx, timeouts, 429) or `Permanent` (4xx). Permanent errors are marked FAILED immediately.

## Digest flush
- One EventBridge schedule per CRON cadence (created and updated by the cadences API). Payload `{cadId}`.
- Window = the previous fire time up to now. Query all 16 shards, group by subId, render the `digest.*` template, send one message per subscription and channel, then delete the flushed items (or let TTL remove them).

## Sending
- Resolve the template: the subscription's `templateId` → the app's template → the global default for that channel. Render with Handlebars (pybars3 or chevron).
- Load the article only if the template needs fields that aren't on the staging item: `s3.get_object(s3Key)`.
- Resolve secrets with a cached Secrets Manager client (5 min TTL).

## Scaling & cost (rough)
- Each change costs 2 + Σ(article values across the source's filter types) single-partition queries (usually under 20) and one BatchGet per 100 matches.
- 100k changes/day × ~15 queries ≈ 1.5M RRU/day, about $0.40/day on demand.
- Watch for hot match keys; shard the PK once one goes past ~10k subscriptions.

## Observability
EMF metrics: `MatchesPerChange`, `QueriesPerChange`, `SendLatencyMs` by channel, `DeliveryFailed` by channel, `DigestItemsFlushed`. Alarms on IteratorAge, DLQ depth > 0 and failure rate > 2%.
