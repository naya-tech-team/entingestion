# Frontend: React

The reference is `design/Subscription Manager.html`; open it alongside this doc. Values below are exact.

## Design tokens (`src/styles/tokens.css` ← `design/styles.css`)
| Token | Value |
|---|---|
| `--color-bg` | #f3f2f2 (page) |
| `--color-surface` | #eae9e9 (inputs, panels) |
| `--color-text` | #201e1d (ink; sidebar background; code panels) |
| `--color-accent` | #ec3013 (primary actions, selected nav, focus) |
| `--color-accent-100/300/400/600/700` | #fff2ef / #ffc4b8 / #ff9783 / #dd2b0f (hover/pressed) / #ae1800 (accent text, links) |
| `--color-neutral-200/300/400/500/600/700/800` | #eae7e7 / #d7d3d3 / #bab6b6 / #9b9797 / #7d7979 / #605d5d / #444141 |
| `--color-divider` | ink at 40% |
| radius | **0 everywhere** |
| shadows | `--shadow-sm/md/lg` (drawer uses lg) |
| spacing | 4 · 8 · 12 · 16 · 24 · 32 |

Type: **Archivo** 400/600/800 for UI and **JetBrains Mono** 400/500/700 for ids, keys, cron and JSON.
- Page title: 26px/800, letter-spacing −0.015em
- Section title: 17–19px/800
- Body: 14px
- Secondary text: 13–13.5px in neutral-700
- Field label: 12px in neutral-700
- Table header: 11px uppercase, letter-spacing .08em, neutral-700
- Breadcrumb: mono 11px in neutral-600

Rules: a 2px ink top border opens every major section. Table rows use 1px divider rules, and table headers use a 2px divider underline.

Interaction states:
- Hover: neutral-200 tint on rows, accent-600 on primary buttons, accent-100 on destructive icon buttons.
- Focus: `:focus-visible { outline: 2px solid var(--color-accent); outline-offset: 2px }`; inputs switch their border to accent.
- Disabled: 45% opacity.

## Shell
- **Sidebar** (240px, sticky, full height, ink background, text in `--color-bg`):
  - Brand row: 14px accent square, "KB Subscriptions" at 15/800, environment in mono 10.5px, then a 2px neutral-800 rule.
  - Role tabs (dev only).
  - For app admins, a "Consumer app" block: label, app name and `APP#{id}` in mono.
  - Nav groups: uppercase 10.5px group label. Items are 8×18px padding, 13.5px, with a 16px lucide icon. The active item has an accent background and 800 weight; hover is neutral-800.
  - Footer: user name and email, plus a sign-out icon button.
- **Header** (sticky, 2px divider bottom, padding 16×28): breadcrumb, H1 and subtitle on the left, primary action button on the right (accent, plus icon, label flush left).
- **Content**: padding 24×28×72, max-width 1400, column gap 20.

### Navigation by role
- **Super admin**
  - Subscriptions: Subscriptions · Consumer apps · Delivery log
  - Backend: Data model · Test event
  - Configuration: Subscription types · Filter types · Sources · Channels · Templates · Cadences
  - Backend: Data model *(optional for production; it's useful as an internal docs page)*
- **App admin**: {App name} → Subscriptions · Delivery log · Templates
- **App user**: Subscriptions (own) · Delivery log (own)

## Screens
Copy (titles, subtitles, button labels) is in the prototype; use it verbatim.

1. **Login.** Two-column grid (auto-fit, min 340px).
   - Left: ink panel with the headline "Know when the knowledge base changes." at 44/800, plus a mono summary.
   - Right: "Sign in", a work email field and "Continue with SSO" (accent, arrow-right). Production uses the OIDC redirect.
2. **Subscriptions list.**
   - Toolbar: search ("Search name, app, owner, source") and a segmented type filter (All/Filter/Article/Source) with counts.
   - Table (min-width 1000, horizontal scroll) with columns Subscription (name + app · owner) | Type tag | Source | Criteria (mono summary) | Cadence | Channels | Status (8px square dot) | actions (edit, pause/resume, delete).
   - Empty state: "No subscriptions match".
   - Delete shows a toast with Undo (5s) and only commits after the toast closes.
3. **Subscription form** (new/edit). Two columns (auto-fit, min 460px).
   - **01 Basics:** name; consumer app (locked for app admins); owner segmented (App / User) with a user select when User is chosen; type cards (icon, label, description) from enabled subscription types.
   - **02 Criteria:** source chips.
     - FILTER: chips for the source's filter types, in priority order. One block per selected type with value chips (mono), an "n of m" count, All and Clear. Values come from `/config/filter-types/{ft}/values?sourceId=`. Show a skeleton while loading and an inline error if the API fails.
     - ARTICLE: server-side search box, chips for picked articles, results list with checkboxes and paging (`artFooter`).
     - SOURCE: the note "Every create, update, and delete in this source triggers a notification."
   - **03 Delivery:** cadence cards (name + cron or "realtime"); channel chips (pick one or more). Each selected channel gets a block with param inputs generated from `paramSchema` (secret → password input) and a template select (global plus this app's).
   - Save (accent; disabled with issues listed) and Cancel.
   - **Right column (sticky, top 110):**
     - "Checks": live validation issues with an icon and colour per issue.
     - Ink code panel "DynamoDB writes on save" with a write count, the subscription item JSON and the match items JSON (accent-300). Fed by `POST …/subscriptions/preview`, debounced 300ms.
   - Changing the source clears filters and articles that are no longer valid.
4. **Delivery log.** Stat strip (Sent / Failed / Retrying / Total) in grid cells, filters (date, status, channel) and a table: time | subscription | article | channel | status | attempts | error. App admins get a retry action on failed rows.
5. **Consumer apps** (super). Card grid (min 280px) showing name, id, admins and users, subscription count, and an edit drawer. "Onboard app" opens the drawer (440px from the right, shadow-lg, backdrop at ink 50%).
6. **Subscription types.** Three cells, each with name, description, fields, match-key pattern (mono) and an enabled toggle.
7. **Filter types.** List on the left (200–260px), editor on the right: name, id, mode segmented (Static / API). Static mode is a values editor. API mode has method, URL, params, headers, valuePath, labelPath, TTL and a **Test** button that calls the resolver.
8. **Sources.** List on the left, editor on the right:
   - API URLs, auth ref, idPath and titlePath.
   - **Filter types:** an ordered list (drag or up/down = priority) with a JSONPath per type and a value source per type (Default / Static / API, with the same editor as filter types).
   - Before saving, show the impact count from `/impact`.
9. **Channels.** List and editor; the param schema editor is rows of key, label, type, required and secret.
10. **Templates.** Scope tabs (Global / app), a list per channel, and an editor (subject, body as a mono textarea) with a preview.
11. **Cadences.** A table of name, kind, cron, timezone and a readable description ("Every day at 8:00 AM ET"; use cronstrue). Deleting a cadence that's in use is blocked with a toast.
12. **Data model** *(optional).* Static docs page rendering `docs/data-model.md`.
13. **Test event** (super: Backend group; app admin: last nav item). Two columns (auto-fit, min 420px).
   - Left side: "Staging event" heading with sample buttons (one per source). The record goes in an ink mono textarea (min-height 380px). Errors show in an accent-100 strip. Buttons: "Send Notification" (accent, play icon) calls `POST /test-events?send=false`, plus "Clear".
   - Right side, four ruled sections from the response:
     - **1 · Parsed article:** a key/value grid of source, article, title, change, and each filter type with its JSONPath and extracted values.
     - **2 · Match index queries:** one row per candidate PK with its item count. Counts above zero are accent-700, bold.
     - **3 · Subscriptions on this source:** name, id · app, a result tag (MATCH filled accent; NO MATCH outlined accent; SKIPPED neutral; NO HIT outlined) and the reason.
     - **4 · Notifications:** one bordered card per subscription × channel with the target, status tag (READY → DELIVERED/QUEUED), cadence note, template name, rendered subject and body. "Send N notifications" calls `?send=true`, then switches to "Open delivery log".

## State & data
- `useMe()` drives role, navigation and the app context. Persist the selected app in the URL: `/apps/:appId/...`.
- `useConfig()` uses a staleTime of 60s. Every config mutation invalidates `['config']`.
- Subscription form: React Hook Form with a Zod schema that mirrors `SubscriptionIn`. `watch()` feeds a debounced preview query.
- Optimistic pause and resume, rolled back on 409.
- Toast system: one at a time, bottom-left, with optional Undo.

## Responsive
Below 900px the sidebar collapses to a top bar with a menu. Tables scroll horizontally. Two-column screens stack.
